 Volume in drive D is Local Disk
 Volume Serial Number is 5E07-5F5C

 Directory of D:\Git\gesture-controlled-robot\release\controller

07/12/2024  16:31    <DIR>          .
07/12/2024  16:31    <DIR>          ..
09/09/2024  17:44                13 controller.ino.eep
09/09/2024  17:44            64,548 controller.ino.elf
09/09/2024  17:44            29,885 controller.ino.hex
09/09/2024  17:44            32,768 controller.ino.with_bootloader.bin
09/09/2024  17:44            30,636 controller.ino.with_bootloader.hex
               5 File(s)        157,850 bytes

 Directory of D:\Git\gesture-controlled-robot\release\robot

07/12/2024  16:31    <DIR>          .
07/12/2024  16:31    <DIR>          ..
09/09/2024  17:44                13 robot.ino.eep
09/09/2024  17:44            36,908 robot.ino.elf
09/09/2024  17:44            10,732 robot.ino.hex
09/09/2024  17:44            32,768 robot.ino.with_bootloader.bin
09/09/2024  17:44            11,896 robot.ino.with_bootloader.hex
               5 File(s)         92,317 bytes
               2 Dir(s)  461,049,278,464 bytes free
