 Volume in drive D is CORNEL
 Volume Serial Number is 5E07-5F5C

 Directory of D:\Git\gesture-controlled-robot\release\controller

29/08/2024  21:56    <DIR>          .
29/08/2024  21:56    <DIR>          ..
28/06/2024  00:35                13 controller.ino.eep
28/06/2024  00:35            64,548 controller.ino.elf
28/06/2024  00:35            29,885 controller.ino.hex
28/06/2024  00:35            32,768 controller.ino.with_bootloader.bin
28/06/2024  00:35            30,636 controller.ino.with_bootloader.hex
               5 File(s)        157,850 bytes

 Directory of D:\Git\gesture-controlled-robot\release\robot

29/08/2024  21:56    <DIR>          .
29/08/2024  21:56    <DIR>          ..
28/06/2024  00:35                13 robot.ino.eep
28/06/2024  00:35            36,908 robot.ino.elf
28/06/2024  00:35            10,732 robot.ino.hex
28/06/2024  00:35            32,768 robot.ino.with_bootloader.bin
28/06/2024  00:35            11,896 robot.ino.with_bootloader.hex
               5 File(s)         92,317 bytes
               2 Dir(s)  259,232,006,144 bytes free
