 Volume in drive D is CORNEL
 Volume Serial Number is 5E07-5F5C

 Directory of D:\Git\gesture-controlled-robot\release\controller

05/09/2024  20:36    <DIR>          .
05/09/2024  20:36    <DIR>          ..
05/09/2024  20:19                13 controller.ino.eep
05/09/2024  20:19            25,348 controller.ino.elf
05/09/2024  20:19            29,885 controller.ino.hex
05/09/2024  20:19            32,768 controller.ino.with_bootloader.bin
05/09/2024  20:19            30,636 controller.ino.with_bootloader.hex
05/09/2024  20:19            78,061 controller.map
               6 File(s)        196,711 bytes

 Directory of D:\Git\gesture-controlled-robot\release\robot

05/09/2024  20:36    <DIR>          .
05/09/2024  20:36    <DIR>          ..
05/09/2024  20:19                13 robot.ino.eep
05/09/2024  20:19            14,888 robot.ino.elf
05/09/2024  20:19            10,732 robot.ino.hex
05/09/2024  20:19            32,768 robot.ino.with_bootloader.bin
05/09/2024  20:19            11,896 robot.ino.with_bootloader.hex
05/09/2024  20:19            40,300 robot.map
               6 File(s)        110,597 bytes
               2 Dir(s)  93,829,455,872 bytes free
